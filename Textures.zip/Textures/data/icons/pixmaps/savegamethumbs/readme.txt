missing id's (created with dead.tga Image to avoid crashes):
1023593803
1025293096
1025293227